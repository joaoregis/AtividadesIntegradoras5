from enum import Enum

class OrderScale(Enum):
    DESCENDING = 0
    ASCENDING = 1